"""
test_kb.py — Verify your Zettelkasten vector database quality

Tests:
  1. Sanity check  — known questions → correct source file retrieved
  2. Similarity    — inspect distances for specific queries
  3. Wrong answer  — out-of-scope query → high distance (no false confidence)
  4. Summary       — pass / fail / warn counts

Run:
  python test_kb.py
"""

import requests
import chromadb
from pathlib import Path

CHROMA_DIR  = "./chroma_db"
OLLAMA_URL  = "http://localhost:11434"
EMBED_MODEL = "nomic-embed-text"

# ── Distance thresholds ───────────────────────────────────────────────────────
GOOD_MATCH   = 0.40   # distance below this = strong retrieval
WEAK_MATCH   = 0.65   # distance above this for top result = warn
OUT_OF_SCOPE = 0.55   # out-of-scope query should be ABOVE this


def embed(text: str) -> list[float]:
    r = requests.post(f"{OLLAMA_URL}/api/embeddings",
                      json={"model": EMBED_MODEL, "prompt": text})
    r.raise_for_status()
    return r.json()["embedding"]


def search(col, query_text: str, top_k: int = 3):
    results = col.query(
        query_embeddings=[embed(query_text)],
        n_results=min(top_k, col.count()),
        include=["documents", "metadatas", "distances"],
    )
    docs      = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0]
    return list(zip(docs, metadatas, distances))


def bar(distance: float, width: int = 30) -> str:
    """Visual distance bar. Shorter = better match."""
    filled = int(distance * width)
    return "█" * filled + "░" * (width - filled)


# ── Test cases ────────────────────────────────────────────────────────────────
SANITY_TESTS = [
    # (question, expected filename stem)
    ("What is a Zettelkasten?",                     "what-is-zettelkasten"),
    ("Who invented the Zettelkasten method?",       "niklas-luhmann"),
    ("What does atomic mean for a note?",           "atomic-note-principle"),
    ("How should I handle fleeting notes daily?",   "fleeting-notes-workflow"),
    ("Why should I write in my own words?",         "writing-in-your-own-words"),
    ("How does linking notes help understanding?",  "linking-notes"),
    ("What is the difference between Zettelkasten and folders?", "zettelkasten-vs-folders"),
    ("How does Zettelkasten help with vector databases?", "zettelkasten-for-vector-db"),
    ("How do I build a daily note habit?",          "daily-note-taking-habit"),
    ("What are the three note types?",              "three-note-types"),
]

SIMILARITY_QUERIES = [
    "emergent connections between ideas",
    "Luhmann slip box index cards",
    "atomic idea one concept per file",
    "processing fleeting notes into permanent",
]

OUT_OF_SCOPE_QUERIES = [
    "what is the capital of France?",
    "how to cook pasta carbonara",
    "best JavaScript frameworks 2024",
]


# ── Runner ─────────────────────────────────────────────────────────────────────
def run():
    col = chromadb.PersistentClient(path=CHROMA_DIR) \
                  .get_collection("knowledge_base")

    total_chunks = col.count()
    print(f"\n{'─'*60}")
    print(f"  Knowledge Base Test Report")
    print(f"  Chunks in DB : {total_chunks}")
    print(f"  Embed model  : {EMBED_MODEL}")
    print(f"{'─'*60}\n")

    if total_chunks == 0:
        print("  ✗ Database is empty. Run: python kb_agent.py ingest")
        return

    passed = warned = failed = 0

    # ── 1. Sanity checks ──────────────────────────────────────────────────────
    print("── Test 1: Sanity checks (right source retrieved?) ─────────────\n")

    for question, expected_stem in SANITY_TESTS:
        hits = search(col, question, top_k=3)
        top_doc, top_meta, top_dist = hits[0]
        top_stem = Path(top_meta["source"]).stem

        if top_stem == expected_stem and top_dist < GOOD_MATCH:
            status = "✓ PASS"
            passed += 1
        elif top_stem == expected_stem and top_dist < WEAK_MATCH:
            status = "~ WARN  (right file, weak distance)"
            warned += 1
        elif top_dist < GOOD_MATCH:
            status = f"~ WARN  (expected '{expected_stem}')"
            warned += 1
        else:
            status = f"✗ FAIL  (expected '{expected_stem}')"
            failed += 1

        print(f"  {status}")
        print(f"  Q : {question}")
        print(f"  → {top_stem}  dist={top_dist:.3f}  {bar(top_dist)}")
        print()

    # ── 2. Similarity inspection ───────────────────────────────────────────────
    print("── Test 2: Similarity inspection (top-3 per query) ─────────────\n")

    for q in SIMILARITY_QUERIES:
        hits = search(col, q, top_k=3)
        print(f"  Query: '{q}'")
        for _, meta, dist in hits:
            stem  = Path(meta["source"]).stem
            label = "✓" if dist < GOOD_MATCH else ("~" if dist < WEAK_MATCH else "✗")
            print(f"    {label} {dist:.3f}  {bar(dist, 20)}  {stem}")
        print()

    # ── 3. Out-of-scope queries ────────────────────────────────────────────────
    print("── Test 3: Out-of-scope queries (distances should be HIGH) ──────\n")

    for q in OUT_OF_SCOPE_QUERIES:
        hits    = search(col, q, top_k=1)
        _, _, d = hits[0]
        if d >= OUT_OF_SCOPE:
            status = "✓ PASS  (correctly low confidence)"
            passed += 1
        else:
            status = "✗ FAIL  (too confident on unrelated query)"
            failed += 1
        print(f"  {status}")
        print(f"  Q : {q}   dist={d:.3f}  {bar(d)}")
        print()

    # ── Summary ────────────────────────────────────────────────────────────────
    total = passed + warned + failed
    print(f"{'─'*60}")
    print(f"  Results:  ✓ {passed} passed  ~ {warned} warned  ✗ {failed} failed  / {total} total")
    print()

    if failed == 0 and warned == 0:
        print("  🟢 Excellent — vectors are clean and retrieval is precise.")
    elif failed == 0:
        print("  🟡 Good — minor issues. Check warned queries and refine those notes.")
    elif failed <= 2:
        print("  🟠 Acceptable — a few misses. Consider rewriting the affected notes")
        print("     to be more self-contained, or adjust CHUNK_SIZE.")
    else:
        print("  🔴 Poor retrieval — notes may be too long, too short, or too generic.")
        print("     Review CHUNK_SIZE and ensure notes are truly atomic.")

    print(f"{'─'*60}\n")


if __name__ == "__main__":
    run()
